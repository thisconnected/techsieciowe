Server 172.16.1.252
client 172.16.1.26


PASV 51807
51808->36341

seq=fcff28d3			win=8192 MSS=1460
seq=c8f038b6 ack=fcff28d4	win=29200 MSS=1460
seq=fcff28d4 ack=c8f038b7	win=256 (65536?)

win=229
win=256

FIN,ACK seq=c8f039f9 ack=fcff291b
ACK	seq=fcff291b ack=c8f039fa
FIN,ACK	seq=fcff291b ack=c8f039fa
ACK	seq=c8f039fa ack=fcff291c
52171	11,12,13 - 14,15,16,20,21 - 27,33,34
52172	17,18,19 - 22,23,24,25,26 - 28 - 29,35,36
#52170	30,31,32 - 40 - 37,38,39 - ;
#60938	1,2,3 - 4,5,6 - 7,8,9,10

52171 	/, /icons/blank.gif
52172 	/icons/folder.gif, /favicon.ico
#52170  connectivity-check.ubuntu.com
#60938 	connectivity-check.ubuntu.com